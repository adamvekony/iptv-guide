# Shared helpers for the IPTV Control Room helper add-on.
import calendar
import json
import os
import re
import time

import xbmc
import xbmcgui
import xbmcvfs

ADDON_ID = 'script.iptv.controlroom'
SKIN_ID = 'skin.iptv.controlroom'
PROFILE = xbmcvfs.translatePath('special://profile/addon_data/%s/' % ADDON_ID)
FAV_FILE = os.path.join(PROFILE, 'favourites.json')
HOME = xbmcgui.Window(10000)
CH_PROPS = ['channelnumber', 'icon', 'uniqueid', 'clientid', 'broadcastnow', 'broadcastnext']


def log(msg):
    xbmc.log('[%s] %s' % (ADDON_ID, msg), xbmc.LOGINFO)


def rpc(method, params=None):
    req = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params or {}}
    res = json.loads(xbmc.executeJSONRPC(json.dumps(req)))
    if 'error' in res:
        log('%s failed: %s' % (method, res['error']))
    return res.get('result') or {}


# ------------------------------------------------------------------ favourites
# Kodi's own favourites list (Add to favourites in the options menu) holds the favourite channels, so they can be added
# and removed with Kodi's menu as well as by the skin. The helper's old favourites.json is migrated once.
_CHANNEL_IN_PATH = re.compile(r'/(\d+)@[^/]+?_(\d+)\.pvr$')


def channel_key(path):
    """(PVR client id, channel unique id) from a channel path such as pvr://channels/tv/All%20channels@-1/1@pvr.iptvsimple_123.pvr"""
    m = _CHANNEL_IN_PATH.search(path or '')
    return (int(m.group(1)), int(m.group(2))) if m else None


def favourite_channels():
    """Kodi favourites that are TV channels, in Kodi's order: list of (path, title)."""
    favs = rpc('Favourites.GetFavourites', {'properties': ['path']}).get('favourites') or []
    return [(f['path'], f.get('title', '')) for f in favs
            if f.get('type') == 'media' and str(f.get('path', '')).startswith('pvr://channels/tv/') and channel_key(f['path'])]


def toggle_favourite(ch, path):
    """Adds the channel to Kodi favourites, or removes it if it is there. Returns True if it is now a favourite."""
    key = (ch['clientid'], ch['uniqueid'])
    existing = next((p for p, _ in favourite_channels() if channel_key(p) == key), None)
    rpc('Favourites.AddFavourite', {'title': ch['label'], 'type': 'media', 'path': existing or path, 'thumbnail': ch.get('icon', '')})
    bump_favs()
    return existing is None


def load_favs():
    """Old helper favourites (channel unique ids) from version 1.0, if any."""
    try:
        with open(FAV_FILE, encoding='utf-8') as f:
            return [int(u) for u in json.load(f).get('uids', [])]
    except (OSError, ValueError):
        return []


def migrate_old_favourites():
    """Moves favourites kept by helper 1.0 into Kodi's favourites list (once)."""
    uids = load_favs()
    if not uids:
        return
    have = {channel_key(p) for p, _ in favourite_channels()}
    by_uid = {c['uniqueid']: c for c in all_channels()}
    if not by_uid:
        return  # channels not loaded yet; try again next start
    build = path_builder()
    for uid in uids:
        ch = by_uid.get(uid)
        if ch and (ch['clientid'], uid) not in have:
            rpc('Favourites.AddFavourite', {'title': ch['label'], 'type': 'media', 'path': build(ch), 'thumbnail': ch.get('icon', '')})
    os.replace(FAV_FILE, FAV_FILE + '.migrated')
    log('moved %d favourites into Kodi favourites' % len(uids))


def bump_favs():
    """Makes the home screen reload its Favourites row."""
    HOME.setProperty('cr.favrev', str(int(time.time() * 1000)))


# ------------------------------------------------------------------ channels
def all_channels():
    return rpc('PVR.GetChannels', {'channelgroupid': 'alltv', 'properties': CH_PROPS}).get('channels', [])


def _kodi_quote(text):
    out = []
    for c in text:
        if c.isascii() and (c.isalnum() or c in '-_.!()'):
            out.append(c)
        else:
            out.extend('%%%02x' % b for b in c.encode('utf-8'))
    return ''.join(out)


def path_builder():
    """Returns f(channel) -> the channel's Kodi path in the all-channels group, which plays it directly."""
    group = rpc('PVR.GetChannelGroupDetails', {'channelgroupid': 'alltv'}).get('channelgroupdetails', {})
    label = group.get('label') or 'All channels'
    addons = {c['clientid']: c['addonid'] for c in rpc('PVR.GetClients').get('clients', [])}

    def build(ch):
        return 'pvr://channels/tv/%s@-1/%d@%s_%d.pvr' % (
            _kodi_quote(label), ch['clientid'], addons.get(ch['clientid'], 'pvr.iptvsimple'), ch['uniqueid'])
    return build


# ------------------------------------------------------------------ guide times (JSON-RPC gives UTC "YYYY-MM-DD HH:MM:SS")
def utc_epoch(text):
    try:
        return calendar.timegm(time.strptime(text, '%Y-%m-%d %H:%M:%S'))
    except (TypeError, ValueError):
        return 0


def local_hm(epoch):
    """Local time in Kodi's region format, without seconds (e.g. 21:30 or 9:30 PM)."""
    fmt = xbmc.getRegion('time').replace(':%S', '')
    text = time.strftime(fmt, time.localtime(epoch))
    return text.lstrip('0') if fmt.startswith('%I') else text
