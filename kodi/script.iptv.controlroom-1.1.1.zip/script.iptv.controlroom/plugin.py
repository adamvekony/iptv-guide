# plugin://script.iptv.controlroom/?mode=favourites  -> the Favourites row (channel items with what is on now)
# plugin://script.iptv.controlroom/?mode=toggle      -> add/remove the focused (or playing) channel as favourite
import sys
import time
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib.common import all_channels, channel_key, favourite_channels, local_hm, log, path_builder, toggle_favourite, utc_epoch


def favourites(handle):
    by_key = {(ch['clientid'], ch['uniqueid']): ch for ch in all_channels()}
    now = time.time()
    for fav_path, _title in favourite_channels():
        ch = by_key.get(channel_key(fav_path))
        if not ch:
            continue
        uid = ch['uniqueid']
        cur = ch.get('broadcastnow') or {}
        nxt = ch.get('broadcastnext') or {}
        li = xbmcgui.ListItem(label=ch['label'], offscreen=True)
        li.setArt({'icon': ch.get('icon', ''), 'thumb': ch.get('icon', '')})
        tag = li.getVideoInfoTag()
        props = {'chno': str(ch.get('channelnumber', '')), 'uid': str(uid), 'channelid': str(ch['channelid'])}
        if cur.get('title'):
            start, end = utc_epoch(cur.get('starttime')), utc_epoch(cur.get('endtime'))
            tag.setTitle(cur['title'])
            tag.setPlot(cur.get('plot') or cur.get('plotoutline') or '')
            if end > start:
                tag.setResumePoint(max(0.0, min(now, end) - start), float(end - start))
            props.update({'starttime': local_hm(start), 'endtime': local_hm(end)})
        if nxt.get('title'):
            props.update({'nexttitle': nxt['title'], 'nextstart': local_hm(utc_epoch(nxt.get('starttime')))})
        li.setProperties(props)
        # Same path as the Kodi favourite, so Kodi's options menu offers "Remove from favourites" here.
        li.setPath(fav_path)
        xbmcplugin.addDirectoryItem(handle, fav_path, li, isFolder=False)
    xbmcplugin.setContent(handle, 'videos')
    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)


def _focused_channel():
    """Channel number and name of the focused list item, or of what is playing."""
    for num_label, name_label in (
        ('ListItem.ChannelNumberLabel', 'ListItem.ChannelName'),
        ('ListItem.Property(chno)', 'ListItem.Label'),
        ('VideoPlayer.ChannelNumberLabel', 'VideoPlayer.ChannelName'),
    ):
        num = xbmc.getInfoLabel(num_label)
        if num.isdigit():
            return int(num), xbmc.getInfoLabel(name_label)
    return None, ''


def toggle():
    num, name = _focused_channel()
    if num is None:
        return
    chans = [c for c in all_channels() if c.get('channelnumber') == num]
    ch = next((c for c in chans if c['label'] == name), chans[0] if chans else None)
    if not ch:
        log('toggle: no channel %s %s' % (num, name))
        return
    added = toggle_favourite(ch, path_builder()(ch))
    msg = 'Added to favourites' if added else 'Removed from favourites'
    xbmcgui.Dialog().notification(ch['label'], msg, ch.get('icon') or xbmcgui.NOTIFICATION_INFO, 2500, False)


if __name__ == '__main__':
    args = urllib.parse.parse_qs(sys.argv[2][1:] if len(sys.argv) > 2 else '')
    mode = (args.get('mode') or ['favourites'])[0]
    if mode == 'toggle':
        toggle()
    else:
        favourites(int(sys.argv[1]))
