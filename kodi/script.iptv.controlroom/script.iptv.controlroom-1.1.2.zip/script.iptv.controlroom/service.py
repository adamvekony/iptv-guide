# Background service: installs the remote key layout while the IPTV Control Room skin is active (and removes it
# otherwise), and refreshes the Favourites row now and then so "what is on now" stays current.
import os
import shutil

import xbmc
import xbmcvfs

from resources.lib.common import ADDON_ID, HOME, SKIN_ID, bump_favs, favourite_channels, log, migrate_old_favourites, repair_favourites, rpc

KEYMAP_SRC = xbmcvfs.translatePath('special://home/addons/%s/resources/keymap.xml' % ADDON_ID)
KEYMAP_DST = xbmcvfs.translatePath('special://profile/keymaps/iptv-controlroom.xml')
REFRESH_EVERY = 300  # seconds
# Kodi only checks add-on repositories about once a day; ask it more often so skin updates arrive the same day
# (with Kodi's automatic updates on, it then installs them by itself).
REPO_CHECK_FIRST = 60
REPO_CHECK_EVERY = 6 * 3600


def _same(a, b):
    try:
        with open(a, 'rb') as fa, open(b, 'rb') as fb:
            return fa.read() == fb.read()
    except OSError:
        return False


def sync_keymap():
    active = xbmc.getSkinDir() == SKIN_ID
    present = os.path.exists(KEYMAP_DST)
    if active and not _same(KEYMAP_SRC, KEYMAP_DST):
        os.makedirs(os.path.dirname(KEYMAP_DST), exist_ok=True)
        shutil.copyfile(KEYMAP_SRC, KEYMAP_DST)
        xbmc.executebuiltin('Action(reloadkeymaps)')
        log('remote key layout installed')
    elif not active and present:
        os.remove(KEYMAP_DST)
        xbmc.executebuiltin('Action(reloadkeymaps)')
        log('remote key layout removed (skin is %s)' % xbmc.getSkinDir())


class PlayingChannel(xbmc.Player):
    """Keeps Window(Home).Property(cr.playingno) = number of the playing TV channel, so the skin can mark it."""

    def _update(self):
        num = xbmc.getInfoLabel('VideoPlayer.ChannelNumberLabel') if xbmc.getCondVisibility('PVR.IsPlayingTV') else ''
        if HOME.getProperty('cr.playingno') != num:
            HOME.setProperty('cr.playingno', num)

    def onAVStarted(self):
        self._update()

    def onAVChange(self):
        self._update()

    def onPlayBackStopped(self):
        HOME.clearProperty('cr.playingno')

    def onPlayBackEnded(self):
        HOME.clearProperty('cr.playingno')

    def onPlayBackError(self):
        HOME.clearProperty('cr.playingno')


def focus_first_row(monitor):
    """At start-up the home rows fill in after the window opens: focus Favourites if there are any, else Recently watched."""
    target = 110 if favourite_channels() else 120
    for _ in range(60):  # up to 30 s: on a cold start the guide and the favourites list need a moment
        if monitor.waitForAbort(0.5):
            return
        if not xbmc.getCondVisibility('Window.IsActive(home)') or xbmc.getSkinDir() != SKIN_ID:
            continue
        if xbmc.getCondVisibility('Integer.IsGreater(Container(%d).NumItems,0)' % target):
            xbmc.executebuiltin('SetFocus(%d)' % target)
            return


def main():
    monitor = xbmc.Monitor()
    player = PlayingChannel()
    player._update()
    try:
        sync_keymap()  # right away, so the remote works before live TV has loaded
    except OSError as e:
        log('keymap: %s' % e)
    # The favourites list needs Kodi's channel list: wait until live TV has loaded, then fill the row.
    for _ in range(120):
        if xbmc.getCondVisibility('PVR.HasTVChannels') or monitor.waitForAbort(0.5):
            break
    try:
        migrate_old_favourites()
        repair_favourites()
    except (OSError, ValueError) as e:
        log('favourites migration: %s' % e)
    fav_state = favourite_channels()
    bump_favs()
    focus_first_row(monitor)
    waited = 0
    guide_set = False
    since_repo_check = REPO_CHECK_EVERY - REPO_CHECK_FIRST
    while not monitor.abortRequested():
        try:
            sync_keymap()
        except OSError as e:
            log('keymap: %s' % e)
        if not guide_set and xbmc.getSkinDir() == SKIN_ID:
            # OK in the guide switches straight to the channel (Kodi's default opens the programme information).
            rpc('Settings.SetSettingValue', {'setting': 'epg.selectaction', 'value': 1})
            guide_set = True
        player._update()  # channel switches inside one playback don't always raise an event
        favs_now = favourite_channels()
        if favs_now != fav_state:  # added or removed with Kodi's options menu
            fav_state = favs_now
            bump_favs()
        if waited >= REFRESH_EVERY and not xbmc.getCondVisibility('Control.HasFocus(110)'):
            bump_favs()
            waited = 0
        if since_repo_check >= REPO_CHECK_EVERY:
            xbmc.executebuiltin('UpdateAddonRepos')
            log('asked Kodi to check add-on repositories for updates')
            since_repo_check = 0
        if monitor.waitForAbort(5):
            break
        waited += 5
        since_repo_check += 5


if __name__ == '__main__':
    main()
