# Shared helpers for the IPTV Control Room helper add-on.
import calendar
import json
import os
import re
import time

import xbmc
import xbmcgui
import xbmcvfs

ADDON_ID = 'script.iptv.controlroom'
SKIN_ID = 'skin.iptv.controlroom'
PROFILE = xbmcvfs.translatePath('special://profile/addon_data/%s/' % ADDON_ID)
FAV_FILE = os.path.join(PROFILE, 'favourites.json')
HOME = xbmcgui.Window(10000)
CH_PROPS = ['channelnumber', 'icon', 'uniqueid', 'clientid', 'broadcastnow', 'broadcastnext']


def log(msg):
    xbmc.log('[%s] %s' % (ADDON_ID, msg), xbmc.LOGINFO)


def rpc(method, params=None):
    req = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params or {}}
    res = json.loads(xbmc.executeJSONRPC(json.dumps(req)))
    if 'error' in res:
        log('%s failed: %s' % (method, res['error']))
    return res.get('result') or {}


# ------------------------------------------------------------------ channel links
# Kodi's link for a channel is pvr://channels/tv/<group>@<id>/<client>@<add-on>_<channel id>.pvr. The <client> number
# and the group name differ between installs (and languages), so the helper never builds links: it reads Kodi's own
# links from its channel folders and matches channels only by the channel id at the end.
_CHANNEL_ID_IN_PATH = re.compile(r'_(-?\d+)\.pvr$')


def channel_uid(path):
    """Channel unique id from a Kodi channel link, or None."""
    m = _CHANNEL_ID_IN_PATH.search(path or '')
    return int(m.group(1)) if m else None


def real_channel_paths():
    """Channel unique id -> Kodi's own link for it in the all-channels group (the group with the most channels)."""
    base = 'pvr://channels/tv/'
    try:
        groups, _ = xbmcvfs.listdir(base)
    except Exception:  # live TV not loaded yet
        return {}
    best = {}
    for group in groups:
        try:
            _, files = xbmcvfs.listdir(base + group + '/')
        except Exception:
            continue
        links = {}
        for name in files:
            uid = channel_uid(name)
            if uid is not None:
                links[uid] = base + group + '/' + name
        if len(links) > len(best):
            best = links
    return best


def all_channels():
    return rpc('PVR.GetChannels', {'channelgroupid': 'alltv', 'properties': CH_PROPS}).get('channels', [])


# ------------------------------------------------------------------ favourites
# Kodi's own favourites list (Add to favourites in the options menu) holds the favourite channels, so they can be added
# and removed with Kodi's menu as well as by the skin. The helper's old favourites.json is migrated once.
def favourite_channels():
    """Kodi favourites that are TV channels, in Kodi's order: list of (link, title, channel id)."""
    favs = rpc('Favourites.GetFavourites', {'properties': ['path']}).get('favourites') or []
    out = []
    for f in favs:
        path = str(f.get('path', ''))
        uid = channel_uid(path)
        if f.get('type') == 'media' and path.startswith('pvr://channels/') and uid is not None:
            out.append((path, f.get('title', ''), uid))
    return out


def toggle_favourite(ch):
    """Adds the channel to Kodi favourites, or removes it if it is there. Returns True/False, or None if not possible."""
    existing = next((p for p, _, uid in favourite_channels() if uid == ch['uniqueid']), None)
    path = existing or real_channel_paths().get(ch['uniqueid'])
    if not path:
        log('toggle: no Kodi link for channel %s' % ch.get('label'))
        return None
    rpc('Favourites.AddFavourite', {'title': ch['label'], 'type': 'media', 'path': path, 'thumbnail': ch.get('icon', '')})
    bump_favs()
    return existing is None


def repair_favourites():
    """Replaces favourite links that are not Kodi's own (helper 1.1.x built them) so they play and can be removed."""
    real = real_channel_paths()
    if not real:
        return
    by_uid = {c['uniqueid']: c for c in all_channels()}
    fixed = 0
    for path, title, uid in favourite_channels():
        good = real.get(uid)
        if good and path != good:
            ch = by_uid.get(uid, {})
            rpc('Favourites.AddFavourite', {'title': title, 'type': 'media', 'path': path})  # same link again = remove
            rpc('Favourites.AddFavourite', {'title': ch.get('label') or title, 'type': 'media', 'path': good,
                                            'thumbnail': ch.get('icon', '')})
            fixed += 1
    if fixed:
        log('repaired %d favourite links' % fixed)
        bump_favs()


def load_favs():
    """Old helper favourites (channel unique ids) from version 1.0, if any."""
    try:
        with open(FAV_FILE, encoding='utf-8') as f:
            return [int(u) for u in json.load(f).get('uids', [])]
    except (OSError, ValueError):
        return []


def migrate_old_favourites():
    """Moves favourites kept by helper 1.0 into Kodi's favourites list (once)."""
    uids = load_favs()
    if not uids:
        return
    real = real_channel_paths()
    if not real:
        return  # channels not loaded yet; try again next start
    have = {uid for _, _, uid in favourite_channels()}
    by_uid = {c['uniqueid']: c for c in all_channels()}
    for uid in uids:
        ch = by_uid.get(uid)
        if ch and uid not in have and uid in real:
            rpc('Favourites.AddFavourite', {'title': ch['label'], 'type': 'media', 'path': real[uid],
                                            'thumbnail': ch.get('icon', '')})
    os.replace(FAV_FILE, FAV_FILE + '.migrated')
    log('moved %d favourites into Kodi favourites' % len(uids))


def bump_favs():
    """Makes the home screen reload its Favourites row."""
    HOME.setProperty('cr.favrev', str(int(time.time() * 1000)))


# ------------------------------------------------------------------ guide times (JSON-RPC gives UTC "YYYY-MM-DD HH:MM:SS")
def utc_epoch(text):
    try:
        return calendar.timegm(time.strptime(text, '%Y-%m-%d %H:%M:%S'))
    except (TypeError, ValueError):
        return 0


def local_hm(epoch):
    """Local time in Kodi's region format, without seconds (e.g. 21:30 or 9:30 PM)."""
    fmt = xbmc.getRegion('time').replace(':%S', '')
    text = time.strftime(fmt, time.localtime(epoch))
    return text.lstrip('0') if fmt.startswith('%I') else text
