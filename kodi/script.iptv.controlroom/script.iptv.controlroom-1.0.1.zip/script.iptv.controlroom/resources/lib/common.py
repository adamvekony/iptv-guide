# Shared helpers for the IPTV Control Room helper add-on.
import calendar
import json
import os
import time

import xbmc
import xbmcgui
import xbmcvfs

ADDON_ID = 'script.iptv.controlroom'
SKIN_ID = 'skin.iptv.controlroom'
PROFILE = xbmcvfs.translatePath('special://profile/addon_data/%s/' % ADDON_ID)
FAV_FILE = os.path.join(PROFILE, 'favourites.json')
HOME = xbmcgui.Window(10000)
CH_PROPS = ['channelnumber', 'icon', 'uniqueid', 'clientid', 'broadcastnow', 'broadcastnext']


def log(msg):
    xbmc.log('[%s] %s' % (ADDON_ID, msg), xbmc.LOGINFO)


def rpc(method, params=None):
    req = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params or {}}
    res = json.loads(xbmc.executeJSONRPC(json.dumps(req)))
    if 'error' in res:
        log('%s failed: %s' % (method, res['error']))
    return res.get('result') or {}


# ------------------------------------------------------------------ favourites (channel unique ids, in the order added)
def load_favs():
    try:
        with open(FAV_FILE, encoding='utf-8') as f:
            return [int(u) for u in json.load(f).get('uids', [])]
    except (OSError, ValueError):
        return []


def save_favs(uids):
    os.makedirs(PROFILE, exist_ok=True)
    tmp = FAV_FILE + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump({'uids': uids}, f)
    os.replace(tmp, FAV_FILE)
    bump_favs()


def bump_favs():
    """Makes the home screen reload its Favourites row."""
    HOME.setProperty('cr.favrev', str(int(time.time() * 1000)))


# ------------------------------------------------------------------ channels
def all_channels():
    return rpc('PVR.GetChannels', {'channelgroupid': 'alltv', 'properties': CH_PROPS}).get('channels', [])


def _kodi_quote(text):
    out = []
    for c in text:
        if c.isascii() and (c.isalnum() or c in '-_.!()'):
            out.append(c)
        else:
            out.extend('%%%02x' % b for b in c.encode('utf-8'))
    return ''.join(out)


def path_builder():
    """Returns f(channel) -> the channel's Kodi path in the all-channels group, which plays it directly."""
    group = rpc('PVR.GetChannelGroupDetails', {'channelgroupid': 'alltv'}).get('channelgroupdetails', {})
    label = group.get('label') or 'All channels'
    addons = {c['clientid']: c['addonid'] for c in rpc('PVR.GetClients').get('clients', [])}

    def build(ch):
        return 'pvr://channels/tv/%s@-1/%d@%s_%d.pvr' % (
            _kodi_quote(label), ch['clientid'], addons.get(ch['clientid'], 'pvr.iptvsimple'), ch['uniqueid'])
    return build


# ------------------------------------------------------------------ guide times (JSON-RPC gives UTC "YYYY-MM-DD HH:MM:SS")
def utc_epoch(text):
    try:
        return calendar.timegm(time.strptime(text, '%Y-%m-%d %H:%M:%S'))
    except (TypeError, ValueError):
        return 0


def local_hm(epoch):
    """Local time in Kodi's region format, without seconds (e.g. 21:30 or 9:30 PM)."""
    fmt = xbmc.getRegion('time').replace(':%S', '')
    text = time.strftime(fmt, time.localtime(epoch))
    return text.lstrip('0') if fmt.startswith('%I') else text
